# -*- coding: utf-8 -*-
"""Búsqueda antropológica multiescala para Pukara del Sol.
Ejecutar en Google Colab: %run /content/openalex_search.py
También puede pegarse el archivo completo en una celda (sin %run).
"""
import sys, subprocess, importlib.util
for package, module in [('requests','requests'),('pandas','pandas'),('openpyxl','openpyxl')]:
    if importlib.util.find_spec(module) is None:
        subprocess.check_call([sys.executable,'-m','pip','-q','install',package])
import os, re, time, hashlib, unicodedata, json
from pathlib import Path
from datetime import datetime
from getpass import getpass
import requests
import pandas as pd

# AJUSTES — caso hipotético; sustituir los topónimos para investigaciones reales.
# Los resultados no constituyen evidencia sobre la comunidad ficticia.
MAX_CONSULTAS_POR_EJECUCION = 90
MAX_RESULTADOS_POR_CONSULTA = 25
MAX_SEMILLAS_POR_EJECUCION = 30
MAX_CITANTES_POR_SEMILLA = 20
BUSCAR_CITANTES = True
PAUSA = 0.35

try:
    from google.colab import drive, userdata
    drive.mount('/content/drive', force_remount=False)
    RAIZ = Path('/content/drive/MyDrive/OpenAlex_Pukara_del_Sol')
except ImportError:
    userdata = None
    RAIZ = Path.cwd() / 'OpenAlex_Pukara_del_Sol'
RAIZ.mkdir(parents=True, exist_ok=True)
SALIDA = RAIZ / 'bibliografia_openalex.xlsx'
RESPALDO = RAIZ / 'respaldo_busqueda.json'

TEMAS = {
 'OS01': ('5.1','Parentesco y familia',['parentesco andino','Andean kinship','ayllu','compadrazgo Andes']),
 'OS02': ('5.1','Reciprocidad y ayuda mutua',['reciprocidad andina','Andean reciprocity','ayni','minka','minga']),
 'OS03': ('5.1','Trabajo colectivo',['faenas comunales','communal labor Andes','trabajo comunal']),
 'OS04': ('5.1','División social del trabajo',['Andean gender division of labor','trabajo familiar campesino','Andean pastoralism gender']),
 'OS05': ('5.1','Pertenencia comunal',['community membership Andes','pertenencia comunal','comuneros calificados']),
 'OS06': ('5.1','Redes de intercambio',['trueque andino','Andean barter','Andean exchange networks']),
 'OS07': ('5.1','Reproducción social',['social reproduction Andes','transmisión cultural andina','economía moral campesina']),
 'OP01': ('5.2','Gobierno comunal',['gobierno comunal','community governance Andes','junta directiva comunal']),
 'OP02': ('5.2','Autoridades tradicionales',['varayoc','varayoq','varayuq','envarados','Andean cargo system']),
 'OP03': ('5.2','Elección y legitimidad',['elecciones comunales','community leadership Andes','legitimidad autoridad comunal']),
 'OP04': ('5.2','Asambleas y decisiones',['asamblea comunal','collective decision making Andes','deliberación comunal']),
 'OP05': ('5.2','Normas y sanciones',['derecho consuetudinario andino','customary law Andes','pluralismo jurídico Perú']),
 'OP06': ('5.2','Organización territorial',['territorialidad comunal','territorial governance Andes','anexos comunales']),
 'OP07': ('5.2','Comunidad y Estado',['comunidades campesinas Estado','communal autonomy Peru','state peasant communities Peru'])
}

# Obras semilla: títulos de referencia, NO citas verificadas ni garantía de indexación.
SEMILLAS = [
 ('Marcel Mauss','The Gift','OS02'),
 ('Bronislaw Malinowski','Argonauts of the Western Pacific','OS06'),
 ('A. R. Radcliffe-Brown','Structure and Function in Primitive Society','OS01'),
 ('Claude Levi-Strauss','The Elementary Structures of Kinship','OS01'),
 ('Marshall Sahlins','Stone Age Economics','OS02'),
 ('Karl Polanyi','The Great Transformation','OS06'),
 ('Eric Wolf','Peasants','OS07'),
 ('Pierre Bourdieu','Outline of a Theory of Practice','OS07'),
 ('John V. Murra','El control vertical de un máximo de pisos ecológicos','OS06'),
 ('Giorgio Alberti Enrique Mayer','Reciprocidad e intercambio en los Andes peruanos','OS02'),
 ('Enrique Mayer','The Articulated Peasant','OS07'),
 ('Olivia Harris','To Make the Earth Bear Fruit','OS04'),
 ('Tristan Platt','Estado boliviano y ayllu andino','OP07'),
 ('Billie Jean Isbell','To Defend Ourselves','OS01'),
 ('Catherine J. Allen','The Hold Life Has','OS02'),
 ('Jose Maria Arguedas','Las comunidades de España y del Perú','OS07'),
 ('Max Weber','Economy and Society','OP03'),
 ('E. E. Evans-Pritchard','The Nuer','OP01'),
 ('Meyer Fortes Evans-Pritchard','African Political Systems','OP01'),
 ('Edmund Leach','Political Systems of Highland Burma','OP03'),
 ('Pierre Clastres','Society Against the State','OP01'),
 ('Victor Turner','The Ritual Process','OP02'),
 ('Sally Falk Moore','Law as Process','OP05'),
 ('James C. Scott','Domination and the Arts of Resistance','OP07'),
 ('Frank Salomon','Native Lords of Quito','OP02'),
 ('Juan Ossio','Parentesco reciprocidad y jerarquía en los Andes','OP02'),
 ('Ricardo Valderrama Carmen Escalante','Nosotros los humanos','OP02')
]

def norm(s):
    s = unicodedata.normalize('NFKD',str(s or '').lower())
    return re.sub(r'\s+',' ',''.join(c for c in s if not unicodedata.combining(c))).strip()
def uid(s): return hashlib.sha1(norm(s).encode()).hexdigest()[:12]
def oaid(s): return str(s or '').rstrip('/').split('/')[-1]
def abstract(inv):
    if not isinstance(inv,dict): return ''
    return ' '.join(w for _,w in sorted((i,w) for w,positions in inv.items() for i in positions))

def consultas():
    q=[]; seen=set()
    def add(text,code,escala,prioridad):
        key=norm(text)
        if key in seen:return
        seen.add(key)
        q.append(dict(id='Q'+uid(key),consulta=text,tema=code,apartado=TEMAS[code][0] if code in TEMAS else "GENERAL",escala=escala,prioridad=prioridad))
    for term in ['Pukara del Sol','Pukara del Sol comunidad campesina','Valle del Cóndor Hatun Pampa','Valle del Cóndor Sierra Central','Hatun Pampa comunidad campesina','Andes centrales comunidades campesinas','Andes peruanos comunidades campesinas']:
        add(term,'GENERAL','LOCAL_DIRECTA',1)
    for code,(_,_,terms) in TEMAS.items():
        for term in terms[:2]:
            for loc in ['Valle del Cóndor','Hatun Pampa']:
                add(loc+' '+term,code,'LOCAL_TEMATICA',2)
        for term in terms[:2]:
            for loc in ['Sierra Central','Andes centrales']:
                add(loc+' '+term,code,'REGIONAL',3)
        for term in terms:
            add('Peru '+term,code,'COMPARATIVA',4)
            add(term,code,'TEORICA',5)
    # Búsquedas autor-concepto (no se exige coincidencia literal de autor en resultados)
    for author, title, code in SEMILLAS:
        add(author+' '+TEMAS[code][2][0],code,'AUTOR_CONCEPTO',6)
    return sorted(q,key=lambda x:(x['prioridad'],x['tema'],x['consulta']))

API_KEY=os.environ.get('OPENALEX_API_KEY','').strip()
if not API_KEY and userdata is not None:
    try: API_KEY=(userdata.get('OPENALEX_API_KEY') or '').strip()
    except Exception: pass
if not API_KEY: API_KEY=getpass('Clave API de OpenAlex: ').strip()
if not API_KEY: raise RuntimeError('Falta la clave API de OpenAlex.')
S=requests.Session(); S.headers['User-Agent']='OpenAlexAcademicSearch/2.0 (academic research)'

def api(params):
    params=dict(params,api_key=API_KEY)
    for n in range(5):
        try:
            r=S.get('https://api.openalex.org/works',params=params,timeout=40)
            if r.status_code==200: return r.json()
            if r.status_code in (401,403): raise RuntimeError(f'Clave API rechazada: HTTP {r.status_code}')
            if r.status_code==429 or r.status_code>=500:
                try: wait=float(r.headers.get('Retry-After',0))
                except ValueError: wait=0
                time.sleep(max(wait,min(45,2**(n+1)))); continue
            raise RuntimeError(f'HTTP {r.status_code}')
        except requests.RequestException:
            if n==4: raise RuntimeError("Error de conexión con OpenAlex") from None
            time.sleep(2**(n+1))
    raise RuntimeError('No se pudo completar la solicitud a OpenAlex')

def metadata(w):
    loc=w.get('primary_location') or {}; oa=w.get('best_oa_location') or {}; source=loc.get('source') or {}
    return dict(id_documento=oaid(w.get('id')),titulo=w.get('display_name') or '',autores=' | '.join((a.get('author') or {}).get('display_name','') for a in w.get('authorships',[]) if (a.get('author') or {}).get('display_name')),anio=w.get('publication_year'),tipo=w.get('type'),publicacion=source.get('display_name'),doi=w.get('doi') or '',url=w.get('doi') or w.get('id'),pdf=oa.get('pdf_url') or loc.get('pdf_url') or '',acceso_abierto=(w.get('open_access') or {}).get('is_oa'),idioma=w.get('language'),resumen=abstract(w.get('abstract_inverted_index')),citas=w.get('cited_by_count'),referencias=len(w.get('referenced_works') or []),consultas_origen=[],semillas=[],escala_busqueda=[],fecha=datetime.now().isoformat(timespec='seconds'),revision='PENDIENTE',pertinencia_validada='',notas='')

def territorial(d):
    txt=norm(d['titulo']+' '+d['resumen'])
    niveles=[('T1_COMUNIDAD',['pukara del sol']),('T2_DISTRITO_PROVINCIA',['valle del condor','hatun pampa']),('T3_REGION',['sierra central']),('T4_MACROREGION',['andes centrales','andes peruanos']),('T5_ANDES',['andes','andean','peruvian highlands'])]
    for label,words in niveles:
        if any(re.search(r'(?<!\w)'+re.escape(word)+r'(?!\w)',txt) for word in words): return label
    return 'T6_SIN_MENCION_TERRITORIAL'

def temas(d):
    t=norm(d['titulo']); a=norm(d['resumen']); out=[]
    for code,(_,_,terms) in TEMAS.items():
        score=sum(3*(norm(x) in t)+(norm(x) in a) for x in terms)
        if score:out.append((code,score))
    return out

# Recuperación persistente. Se conservan notas manuales del Excel al reabrirlo.
STATE={'documentos':{},'consultas':{},'semillas':{},'relaciones':[]}
if RESPALDO.exists():
    try: STATE=json.loads(RESPALDO.read_text(encoding='utf-8'))
    except Exception as e: print('Advertencia: respaldo JSON ilegible:',e)
if SALIDA.exists():
    try:
        prev=pd.read_excel(SALIDA,sheet_name=None,dtype=str).fillna('')
        for row in prev.get('BIBLIOGRAFIA',pd.DataFrame()).to_dict('records'):
            key=row.get('id_documento','')
            if key and key in STATE['documentos']:
                for field in ['revision','pertinencia_validada','notas']:
                    if row.get(field):STATE['documentos'][key][field]=row[field]
        for row in prev.get('EVIDENCIAS',pd.DataFrame()).to_dict('records'):
            pass  # Se conserva la hoja completa más abajo.
        evidencias_prev=prev.get('EVIDENCIAS',pd.DataFrame())
        matrices_prev={k:prev.get(k,pd.DataFrame()) for k in ['MATRIZ_5_1','MATRIZ_5_2']}
    except Exception as e:
        print('Advertencia: no se pudo leer el Excel anterior:',e)
        evidencias_prev=pd.DataFrame(); matrices_prev={}
else:
    evidencias_prev=pd.DataFrame(); matrices_prev={}

def checkpoint():
    temp=RESPALDO.with_suffix('.tmp')
    temp.write_text(json.dumps(STATE,ensure_ascii=False,default=str),encoding='utf-8')
    os.replace(temp,RESPALDO)

def incorporar(w,origen,escala,semilla=None):
    d=metadata(w); key=d['id_documento']
    if not key:return False
    old=STATE['documentos'].get(key)
    if old:
        for field in ['resumen','pdf','doi','publicacion','idioma']:
            if not old.get(field) and d.get(field):old[field]=d[field]
        d=old
    else:STATE['documentos'][key]=d
    for field,value in [('consultas_origen',origen),('escala_busqueda',escala),('semillas',semilla)]:
        if isinstance(d.get(field),str): d[field]=[x for x in d[field].split(' | ') if x]
        if value and value not in d[field]:d[field].append(value)
    return old is None

# Etapa A: consultas multiescala. Selección intercalada por tema dentro de cada nivel.
allq=consultas(); pending=[q for q in allq if STATE['consultas'].get(q['id'],{}).get('estado')!='COMPLETADA']
selected=[]
for p in sorted(set(q['prioridad'] for q in pending)):
    group=[q for q in pending if q['prioridad']==p]
    while group and len(selected)<MAX_CONSULTAS_POR_EJECUCION:
        used=set(); nxt=[]
        for q in group:
            if q['tema'] not in used and len(selected)<MAX_CONSULTAS_POR_EJECUCION:
                selected.append(q);used.add(q['tema'])
            else:nxt.append(q)
        group=nxt
print(f'Consultas pendientes: {len(pending)} | Ejecutando: {len(selected)}')
for i,q in enumerate(selected,1):
    try:
        results=api({'search':q['consulta'],'per-page':MAX_RESULTADOS_POR_CONSULTA}).get('results',[])
        nuevos=sum(incorporar(w,q['id'],q['escala']) for w in results)
        STATE['consultas'][q['id']]=dict(q,estado='COMPLETADA',resultados=len(results),nuevos=nuevos,error='',fecha=datetime.now().isoformat(timespec='seconds'))
        print(f'[{i}/{len(selected)}] {q["escala"]}: {q["consulta"]} -> {len(results)} / {nuevos} nuevos')
    except Exception as e:
        STATE['consultas'][q['id']]=dict(q,estado='ERROR',resultados=0,nuevos=0,error=str(e),fecha=datetime.now().isoformat(timespec='seconds'))
        print('ERROR:',q['consulta'],str(e))
        if 'Clave API rechazada' in str(e):break
    if i%5==0:checkpoint()
    time.sleep(PAUSA)
checkpoint()

# Etapa B: identificar obras semilla por título + autor; resultados candidatos, nunca validación automática.
for j,(author,title,code) in enumerate(SEMILLAS[:MAX_SEMILLAS_POR_EJECUCION],1):
    sid='S'+uid(author+' '+title)
    if STATE['semillas'].get(sid,{}).get('estado')=='COMPLETADA':continue
    try:
        found=api({'search':title+' '+author,'per-page':10}).get('results',[])
        # Comparar título y autor sin asumir que primer resultado es el correcto.
        candidates=[]
        title_words=set(norm(title).split())
        author_tokens=[x for x in norm(author).split() if len(x)>3]
        for w in found:
            wt=set(norm(w.get('display_name')).split())
            title_overlap=len(title_words & wt)/max(1,len(title_words))
            authors=norm(' '.join((a.get('author') or {}).get('display_name','') for a in w.get('authorships',[])))
            author_overlap=any(tok in authors for tok in author_tokens[-2:])
            if title_overlap>=0.65 and author_overlap:
                candidates.append((title_overlap,w))
        candidates.sort(key=lambda x:x[0],reverse=True)
        if candidates:
            w=candidates[0][1]; incorporar(w,'SEMILLA:'+sid,'CLASICO',sid)
            STATE['semillas'][sid]=dict(id_semilla=sid,autor=author,obra=title,tema=code,estado='COMPLETADA',id_openalex=oaid(w['id']),coincidencia=candidates[0][0],nota='Candidato bibliográfico; comprobar edición y autoría')
        else:
            STATE['semillas'][sid]=dict(id_semilla=sid,autor=author,obra=title,tema=code,estado='NO_LOCALIZADA',id_openalex='',coincidencia=0,nota='Buscar en catálogos/repositorios; OpenAlex no confirmó coincidencia')
    except Exception as e:
        STATE['semillas'][sid]=dict(id_semilla=sid,autor=author,obra=title,tema=code,estado='ERROR',id_openalex='',coincidencia=0,nota=str(e))
    if j%5==0:checkpoint()
    time.sleep(PAUSA)
checkpoint()

# Etapa C: rastrear publicaciones que citan obras semilla (si OpenAlex las indexa).
if BUSCAR_CITANTES:
    done={(x['semilla'],x['documento']) for x in STATE['relaciones']}
    for sid,s in STATE['semillas'].items():
        if s['estado']!='COMPLETADA' or not s.get('id_openalex'):continue
        try:
            citing=api({'filter':'cites:'+s['id_openalex'],'per-page':MAX_CITANTES_POR_SEMILLA}).get('results',[])
            for w in citing:
                did=oaid(w.get('id'))
                if not did:continue
                incorporar(w,'CITANTE:'+sid,'RED_CITACIONES',sid)
                if (sid,did) not in done:
                    STATE['relaciones'].append({'semilla':sid,'documento':did,'tipo':'CITA_LA_OBRA'});done.add((sid,did))
        except Exception as e:print('No se pudieron obtener citantes:',sid,e)
        time.sleep(PAUSA)
checkpoint()

# Salida: hojas con metadatos, asociaciones preliminares y espacios para validación humana.
docs=[dict(d) for d in STATE['documentos'].values()]
for d in docs:
    d['nivel_territorial_auto']=territorial(d)
    d['temas_candidatos_auto']=' | '.join(f'{k}:{score}' for k,score in temas(d))
    for field in ['consultas_origen','escala_busqueda','semillas']:
        if isinstance(d.get(field),list):d[field]=' | '.join(d[field])
mat={'5.1':[],'5.2':[]}
for d in docs:
    scores=dict(temas(d))
    # Añadir asociación por semilla incluso si el resumen no contiene términos.
    for sid in str(d.get('semillas') or '').split(' | '):
        seed=STATE['semillas'].get(sid)
        if seed and seed['tema'] in TEMAS:scores.setdefault(seed['tema'],0)
    for code,score in scores.items():
        apartado,nombre,_=TEMAS[code]
        mat[apartado].append(dict(id_documento=d['id_documento'],codigo_tema=code,tema=nombre,titulo=d['titulo'],autores=d['autores'],anio=d['anio'],nivel_territorial_auto=d['nivel_territorial_auto'],puntuacion_lexica_auto=score,tipo_aporte='',concepto_util='',hallazgo_documental='',afirmacion_sustentable='',pagina='',limitaciones='',pertinencia_validada='',estado_revision='PENDIENTE',url=d['url']))

# Conservar evaluaciones hechas manualmente en matrices previas.
manual=['tipo_aporte','concepto_util','hallazgo_documental','afirmacion_sustentable','pagina','limitaciones','pertinencia_validada','estado_revision']
for apartado,sheet in [('5.1','MATRIZ_5_1'),('5.2','MATRIZ_5_2')]:
    prev=matrices_prev.get(sheet,pd.DataFrame())
    if not prev.empty and {'id_documento','codigo_tema'}.issubset(prev.columns):
        lookup={(r['id_documento'],r['codigo_tema']):r for r in prev.to_dict('records')}
        existing={(r['id_documento'],r['codigo_tema']) for r in mat[apartado]}
        for row in mat[apartado]:
            old=lookup.get((row['id_documento'],row['codigo_tema']))
            if old:
                for field in manual:
                    if old.get(field) not in ('',None):row[field]=old[field]
        for key,old in lookup.items():
            if key not in existing:mat[apartado].append(old)

cols_ev=['id_evidencia','apartado','codigo_tema','id_documento','tipo_fuente','cita_literal','pagina_localizador','hallazgo','interpretacion_antropologica','alcance_territorial','verificacion','limitaciones','observaciones']
if evidencias_prev.empty:evidencias_prev=pd.DataFrame(columns=cols_ev)
frames={
 'BIBLIOGRAFIA':pd.DataFrame(docs),
 'MATRIZ_5_1':pd.DataFrame(mat['5.1']),
 'MATRIZ_5_2':pd.DataFrame(mat['5.2']),
 'OBRAS_SEMILLA':pd.DataFrame(STATE['semillas'].values()),
 'RED_CITACIONES':pd.DataFrame(STATE['relaciones']),
 'EVIDENCIAS':evidencias_prev,
 'CONTROL':pd.DataFrame(STATE['consultas'].values()),
 'DICCIONARIO':pd.DataFrame([dict(codigo=k,apartado=v[0],tema=v[1],terminos=' | '.join(v[2])) for k,v in TEMAS.items()])
}
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
with pd.ExcelWriter(SALIDA,engine='openpyxl') as writer:
    for name,df in frames.items():
        if df.empty and len(df.columns)==0:df=pd.DataFrame(columns=['sin_resultados'])
        df.to_excel(writer,sheet_name=name,index=False)
        ws=writer.sheets[name];ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
        for row in ws.iter_rows():
            for cell in row:
                if cell.data_type == 'f': cell.data_type = 's'
        for cell in ws[1]:
            cell.fill=PatternFill('solid',fgColor='153A5B');cell.font=Font(color='FFFFFF',bold=True)
            cell.alignment=Alignment(wrap_text=True,vertical='center')
        for i,col in enumerate(df.columns,1):
            ws.column_dimensions[get_column_letter(i)].width=65 if col in ('titulo','resumen','hallazgo_documental','cita_literal','afirmacion_sustentable') else 24
print('\nRESULTADO:',SALIDA)
print('Documentos únicos:',len(docs),'| Asociaciones 5.1:',len(mat['5.1']),'| Asociaciones 5.2:',len(mat['5.2']))
print('Obras semilla localizadas:',sum(x['estado']=='COMPLETADA' for x in STATE['semillas'].values()),'de',len(SEMILLAS))
print('Consultas completadas:',sum(x['estado']=='COMPLETADA' for x in STATE['consultas'].values()),'de',len(allq))
print('Ejecuta nuevamente para continuar consultas pendientes; revisa los candidatos antes de citarlos.')
