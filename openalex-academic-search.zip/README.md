# OpenAlex Academic Search

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pedrohuarhua85-crypto/openalex-academic-search/blob/main/openalex_search.ipynb)

Herramienta Python para búsqueda bibliográfica multiescala, clasificación temática preliminar, obras semilla, citaciones y exportación Excel. Usa exclusivamente OpenAlex.

## Uso
1. Abre el notebook en Colab o instala `pip install -r requirements.txt` y ejecuta `python openalex_search.py`.
2. Obtén tu clave en https://openalex.org/ y guárdala como secreto `OPENALEX_API_KEY` o introdúcela de forma privada al ejecutar.
3. Edita `consultas()`, `territorial()`, `TEMAS` y `SEMILLAS` según tu investigación. Cambia también la carpeta de salida para cada proyecto.
4. Ejecuta y revisa el Excel y el respaldo JSON. Repite con la misma configuración para continuar búsquedas pendientes.

Pukara del Sol, Valle del Cóndor y Hatun Pampa son nombres ilustrativos, no un caso etnográfico documentado. No interpretes resultados como evidencia de su existencia. Las coincidencias temáticas y obras semilla requieren validación humana. La cobertura depende de OpenAlex y de los límites de consulta; no es una revisión sistemática exhaustiva. No publiques claves ni resultados privados.

## English
Python toolkit for multiscale academic literature discovery using OpenAlex only. Includes preliminary thematic matching, seed works, citation tracking, deduplication, Excel export and persistent search state. Open the notebook in Colab, supply your own API key securely, and edit the example search terms and output folder. The example community is fictional; matches require manual verification.

License: MIT (see repository LICENSE).
